import { cors, state, apiError } from './_core.js';
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try { return res.status(200).json(await state()); } catch (e) { return apiError(res, e); }
}
