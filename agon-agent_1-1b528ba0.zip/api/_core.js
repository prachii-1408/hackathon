import crypto from 'node:crypto';
import supabase from './db-client.js';

export const BUCKET = 'vault-replicas';
export const sha = buffer => crypto.createHash('sha256').update(buffer).digest('hex');
export const accessible = node => node && node.status !== 'OFFLINE' && !node.partitioned;
export const apiError = (res, error) => { console.error('[Vault]', error); return res.status(500).json({ error: error?.message || 'Unexpected server error' }); };
export function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') { res.status(204).end(); return true; }
  return false;
}
export async function query(table, options = {}) {
  let q = supabase.from(table).select('*');
  if (options.eq) q = q.eq(options.eq[0], options.eq[1]);
  if (options.order) q = q.order(options.order, { ascending: options.asc ?? false });
  if (options.limit) q = q.limit(options.limit);
  const { data, error } = await q;
  if (error) throw error;
  return data;
}
export async function write(table, row) {
  const { data, error } = await supabase.from(table).insert(row).select('*').single();
  if (error) throw error;
  return data;
}
export async function change(table, id, changes) {
  const { data, error } = await supabase.from(table).update(changes).eq('id', id).select('*').single();
  if (error) throw error;
  return data;
}
export async function log(event_type, message, detail = '') { return write('vault_audit', { event_type, message, detail }); }
export async function state() {
  const [nodes, objects, replicas, events] = await Promise.all([
    query('vault_nodes', { order: 'id', asc: true }),
    query('vault_objects', { order: 'created_at' }),
    query('vault_replicas', { order: 'created_at' }),
    query('vault_audit', { order: 'created_at', limit: 100 })
  ]);
  return { nodes, objects, replicas, events, generated_at: new Date().toISOString() };
}
export async function storeReplica(object, node, buffer) {
  const path = `${node.id}/${object.id}/v${object.version}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, buffer, { contentType: object.mime_type || 'application/octet-stream', upsert: true });
  if (error) throw error;
  const checksum = sha(buffer);
  if (checksum !== object.checksum) throw new Error('Source checksum mismatch');
  const { data: blob, error: readError } = await supabase.storage.from(BUCKET).download(path);
  if (readError) throw readError;
  if (sha(Buffer.from(await blob.arrayBuffer())) !== object.checksum) throw new Error('Replica verification failed');
  const existing = (await query('vault_replicas', { eq: ['object_id', object.id] })).find(r => r.node_id === node.id);
  const replica = existing ? await change('vault_replicas', existing.id, { status: 'HEALTHY', checksum, verified_at: new Date().toISOString(), path }) : await write('vault_replicas', { id: crypto.randomUUID(), object_id: object.id, node_id: node.id, path, checksum, status: 'HEALTHY', verified_at: new Date().toISOString() });
  await change('vault_nodes', node.id, { write_ops: node.write_ops + 1 });
  return replica;
}
export async function verifyReplica(replica, object, node) {
  if (!accessible(node)) return null;
  if (node.latency_ms > 0) await new Promise(resolve => setTimeout(resolve, Math.min(node.latency_ms, 500)));
  const { data, error } = await supabase.storage.from(BUCKET).download(replica.path);
  if (error || !data) {
    if (replica.status !== 'MISSING') { await change('vault_replicas', replica.id, { status: 'MISSING' }); await log('FAILURE', `Replica unavailable on ${replica.node_id}`, object.filename); }
    return null;
  }
  const buffer = Buffer.from(await data.arrayBuffer());
  if (sha(buffer) !== object.checksum) {
    if (replica.status !== 'CORRUPTED') { await change('vault_replicas', replica.id, { status: 'CORRUPTED' }); await log('CORRUPTION', `Checksum mismatch on ${replica.node_id}`, object.filename); }
    return null;
  }
  await change('vault_replicas', replica.id, { status: 'HEALTHY', verified_at: new Date().toISOString(), checksum: object.checksum });
  await change('vault_nodes', node.id, { read_ops: node.read_ops + 1 });
  return buffer;
}
export async function updateObjectStatus(object) {
  const [replicas, nodes] = await Promise.all([query('vault_replicas', { eq: ['object_id', object.id] }), query('vault_nodes')]);
  const valid = replicas.filter(r => r.status === 'HEALTHY' && accessible(nodes.find(n => n.id === r.node_id))).length;
  const status = valid >= object.replication_factor ? 'HEALTHY' : valid > 0 ? 'DEGRADED' : 'UNAVAILABLE';
  if (object.status !== status) await change('vault_objects', object.id, { status });
  return status;
}
export async function refreshUsage() {
  const [nodes, objects, replicas] = await Promise.all([query('vault_nodes'), query('vault_objects'), query('vault_replicas')]);
  const sizes = new Map(objects.map(o => [o.id, Number(o.size_bytes)]));
  for (const node of nodes) {
    const used = replicas.filter(r => r.node_id === node.id).reduce((sum, r) => sum + (sizes.get(r.object_id) || 0), 0);
    if (Number(node.used_bytes) !== used) await change('vault_nodes', node.id, { used_bytes: used });
  }
}
export async function repairObject(object) {
  const nodes = await query('vault_nodes');
  let replicas = await query('vault_replicas', { eq: ['object_id', object.id] });
  let source = null;
  for (const r of replicas) {
    const buffer = await verifyReplica(r, object, nodes.find(n => n.id === r.node_id));
    if (buffer && !source) source = buffer;
  }
  replicas = await query('vault_replicas', { eq: ['object_id', object.id] });
  let healthy = replicas.filter(r => r.status === 'HEALTHY' && accessible(nodes.find(n => n.id === r.node_id)));
  if (!source) { await updateObjectStatus(object); await log('FAILURE', `No verified source available for ${object.filename}`, 'Repair deferred until a healthy node returns'); return { repaired: 0, status: 'UNAVAILABLE' }; }
  let repaired = 0;
  const candidates = nodes.filter(accessible).sort((a, b) => Number(a.used_bytes) - Number(b.used_bytes));
  for (const node of candidates) {
    if (healthy.length >= object.replication_factor) break;
    if (healthy.some(r => r.node_id === node.id)) continue;
    const existing = replicas.find(r => r.node_id === node.id);
    if (Number(node.used_bytes) + Number(object.size_bytes) > Number(node.capacity_bytes) && !existing) continue;
    try {
      const replica = await storeReplica(object, node, source);
      healthy.push(replica);
      repaired++;
      await log('REPAIR', `Replica restored on ${node.id}`, object.filename);
    } catch (e) { await log('FAILURE', `Repair failed on ${node.id}`, e.message); }
  }
  // Recovery can make previously offline copies accessible again. Trim only
  // verified surplus copies, and never reduce durability below the policy.
  if (healthy.length > object.replication_factor) {
    const surplus = [...healthy].sort((a, b) => Number(nodes.find(n => n.id === b.node_id)?.used_bytes || 0) - Number(nodes.find(n => n.id === a.node_id)?.used_bytes || 0));
    for (const replica of surplus) {
      if (healthy.length <= object.replication_factor || healthy.length <= 1) break;
      const { error: storageError } = await supabase.storage.from(BUCKET).remove([replica.path]);
      if (storageError) { await log('FAILURE', `Could not trim surplus on ${replica.node_id}`, storageError.message); continue; }
      const { error: deleteError } = await supabase.from('vault_replicas').delete().eq('id', replica.id);
      if (deleteError) { await log('FAILURE', `Could not remove surplus metadata on ${replica.node_id}`, deleteError.message); continue; }
      healthy = healthy.filter(r => r.id !== replica.id);
      await log('REBALANCE', `Surplus replica retired on ${replica.node_id}`, object.filename);
    }
  }
  await refreshUsage();
  const status = await updateObjectStatus(object);
  return { repaired, status };
}
export async function repairAll() {
  let repaired = 0;
  for (const object of await query('vault_objects')) {
    const result = await repairObject(object);
    repaired += result.repaired;
  }
  return repaired;
}
export async function updateAllStatuses() { for (const object of await query('vault_objects')) await updateObjectStatus(object); }
