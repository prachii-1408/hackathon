import crypto from 'node:crypto';
import supabase from './db-client.js';
import { cors, query, write, change, log, sha, accessible, storeReplica, updateObjectStatus, refreshUsage, apiError, BUCKET } from './_core.js';
export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    if (req.method === 'GET') return res.status(200).json(await query('vault_objects', { order: 'created_at' }));
    if (req.method === 'POST') {
      const { filename, mime_type, file_base64, replication_factor } = req.body || {};
      const factor = Number(replication_factor);
      if (!filename?.trim() || typeof file_base64 !== 'string' || !Number.isInteger(factor) || factor < 1 || factor > 5) return res.status(400).json({ error: 'File and replication factor (1–5) are required.' });
      const buffer = Buffer.from(file_base64, 'base64');
      if (!buffer.length || buffer.length > 2 * 1024 * 1024) return res.status(400).json({ error: 'Choose a file between 1 byte and 2 MB.' });
      const nodes = (await query('vault_nodes')).filter(accessible).sort((a, b) => Number(a.used_bytes) / Number(a.capacity_bytes) - Number(b.used_bytes) / Number(b.capacity_bytes));
      if (!nodes.length) return res.status(400).json({ error: 'No accessible nodes are available.' });
      const object = await write('vault_objects', { id: crypto.randomUUID(), filename: filename.trim().slice(0, 200), size_bytes: buffer.length, mime_type: mime_type || 'application/octet-stream', checksum: sha(buffer), version: 1, replication_factor: factor, status: 'PENDING' });
      let success = 0;
      for (const node of nodes.slice(0, factor)) {
        if (Number(node.used_bytes) + buffer.length > Number(node.capacity_bytes)) continue;
        try { await storeReplica(object, node, buffer); success++; } catch (e) { await log('FAILURE', `Write failed on ${node.id}`, e.message); }
      }
      await refreshUsage();
      const status = await updateObjectStatus(object);
      await log('UPLOAD', `${object.filename} stored with ${success}/${factor} replicas`, `${(buffer.length / 1024).toFixed(1)} KB · SHA-256 verified`);
      return res.status(201).json({ ...object, status });
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Object ID is required.' });
      const object = (await query('vault_objects', { eq: ['id', id] }))[0];
      if (!object) return res.status(404).json({ error: 'Object not found.' });
      const replicas = await query('vault_replicas', { eq: ['object_id', id] });
      // Explicit object deletion is the only operation allowed to remove the last copy.
      if (replicas.length) {
        const { error: storageError } = await supabase.storage.from(BUCKET).remove(replicas.map(r => r.path));
        if (storageError) throw storageError;
        const { error } = await supabase.from('vault_replicas').delete().eq('object_id', id);
        if (error) throw error;
      }
      const { error } = await supabase.from('vault_objects').delete().eq('id', id);
      if (error) throw error;
      await refreshUsage();
      await log('DELETE', `${object.filename} permanently deleted`, `${replicas.length} replicas removed`);
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) { return apiError(res, e); }
}
