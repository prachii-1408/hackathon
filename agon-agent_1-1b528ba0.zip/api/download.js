import { cors, query, verifyReplica, repairObject, log, apiError } from './_core.js';
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const object = (await query('vault_objects', { eq: ['id', req.query.id] }))[0];
    if (!object) return res.status(404).json({ error: 'Object not found.' });
    const [replicas, nodes] = await Promise.all([query('vault_replicas', { eq: ['object_id', object.id] }), query('vault_nodes')]);
    for (const replica of replicas.sort((a, b) => a.node_id.localeCompare(b.node_id))) {
      const buffer = await verifyReplica(replica, object, nodes.find(n => n.id === replica.node_id));
      if (buffer) {
        await repairObject(object);
        await log('READ', `${object.filename} retrieved from ${replica.node_id}`, 'SHA-256 verified before delivery');
        res.setHeader('Content-Type', object.mime_type);
        res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(object.filename)}`);
        res.setHeader('Content-Length', buffer.length);
        return res.status(200).send(buffer);
      }
    }
    await repairObject(object);
    return res.status(503).json({ error: 'No verified replica is currently available. Restore a node and try again.' });
  } catch (e) { return apiError(res, e); }
}
