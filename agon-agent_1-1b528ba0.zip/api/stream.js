import { state } from './_core.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  let count = 0;
  const send = async () => {
    try { res.write(`event: snapshot\ndata: ${JSON.stringify(await state())}\n\n`); }
    catch (e) { res.write(`event: error\ndata: ${JSON.stringify({ error: e.message })}\n\n`); }
    if (++count >= 5) { clearInterval(timer); res.end(); }
  };
  const timer = setInterval(send, 4000);
  await send();
  req.on('close', () => clearInterval(timer));
}
