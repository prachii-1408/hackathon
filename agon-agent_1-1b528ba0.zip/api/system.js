import supabase from './db-client.js';
import { cors, query, change, log, verifyReplica, repairAll, repairObject, updateObjectStatus, refreshUsage, storeReplica, accessible, apiError, BUCKET } from './_core.js';
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { action, object_id, node_id } = req.body || {};
    if (action === 'verify') {
      let checked = 0, corrupted = 0;
      const nodes = await query('vault_nodes');
      for (const object of await query('vault_objects')) {
        const replicas = await query('vault_replicas', { eq: ['object_id', object.id] });
        for (const replica of replicas) {
          if (!accessible(nodes.find(n => n.id === replica.node_id))) continue;
          checked++;
          if (!await verifyReplica(replica, object, nodes.find(n => n.id === replica.node_id))) corrupted++;
        }
        await updateObjectStatus(object);
      }
      await log('INTEGRITY', `Integrity sweep complete`, `${checked} replicas checked · ${corrupted} failed`);
      const repaired = await repairAll();
      return res.status(200).json({ message: `${checked} replicas verified, ${corrupted} failed, ${repaired} repaired.` });
    }
    if (action === 'repair') {
      const repaired = object_id ? await (async () => { const o = (await query('vault_objects', { eq: ['id', object_id] }))[0]; if (!o) throw new Error('Object not found'); return (await repairObject(o)).repaired; })() : await repairAll();
      await log('REPAIR', 'Manual repair cycle completed', `${repaired} replicas restored`);
      return res.status(200).json({ message: `Repair complete. ${repaired} replicas restored.` });
    }
    if (action === 'corrupt') {
      const object = (await query('vault_objects', { eq: ['id', object_id] }))[0];
      const replica = (await query('vault_replicas', { eq: ['object_id', object_id] })).find(r => r.node_id === node_id);
      if (!object || !replica) return res.status(404).json({ error: 'Replica not found.' });
      const { error } = await supabase.storage.from(BUCKET).upload(replica.path, Buffer.from('VAULT_CORRUPTED_REPLICA_' + Date.now()), { contentType: 'application/octet-stream', upsert: true });
      if (error) throw error;
      await change('vault_replicas', replica.id, { status: 'CORRUPTED' });
      await log('CORRUPTION', `Injected checksum corruption on ${node_id}`, object.filename);
      await updateObjectStatus(object);
      const result = await repairObject(object);
      return res.status(200).json({ message: `Corruption detected on ${node_id}; automatic repair restored ${result.repaired} replica${result.repaired === 1 ? '' : 's'}.` });
    }
    if (action === 'rebalance') {
      const [nodes, objects] = await Promise.all([query('vault_nodes'), query('vault_objects')]);
      let moved = 0;
      for (const object of objects) {
        const replicas = await query('vault_replicas', { eq: ['object_id', object.id] });
        const source = replicas.filter(r => r.status === 'HEALTHY' && accessible(nodes.find(n => n.id === r.node_id))).sort((a, b) => Number(nodes.find(n => n.id === b.node_id).used_bytes) - Number(nodes.find(n => n.id === a.node_id).used_bytes))[0];
        const target = nodes.filter(n => accessible(n) && !replicas.some(r => r.node_id === n.id) && Number(n.used_bytes) + Number(object.size_bytes) <= Number(n.capacity_bytes)).sort((a, b) => Number(a.used_bytes) - Number(b.used_bytes))[0];
        if (!source || !target) continue;
        const sourceNode = nodes.find(n => n.id === source.node_id);
        if (Number(sourceNode.used_bytes) - Number(target.used_bytes) < Number(object.size_bytes)) continue;
        const buffer = await verifyReplica(source, object, sourceNode);
        if (!buffer) continue;
        try {
          await storeReplica(object, target, buffer);
          // Copy and verify first. Never delete the only healthy copy.
          const validCount = (await query('vault_replicas', { eq: ['object_id', object.id] })).filter(r => r.status === 'HEALTHY').length;
          if (validCount > 1) {
            const { error } = await supabase.storage.from(BUCKET).remove([source.path]);
            if (error) throw error;
            const { error: deleteError } = await supabase.from('vault_replicas').delete().eq('id', source.id);
            if (deleteError) throw deleteError;
            moved++;
            await log('REBALANCE', `${object.filename} moved ${source.node_id} → ${target.id}`, 'Target verified before source removed');
            await refreshUsage();
            const fresh = await query('vault_nodes');
            fresh.forEach(n => { const old = nodes.find(x => x.id === n.id); if (old) old.used_bytes = n.used_bytes; });
          }
        } catch (e) { await log('FAILURE', 'Rebalance transfer failed', e.message); }
      }
      return res.status(200).json({ message: `Rebalance complete. ${moved} replicas migrated.` });
    }
    if (action === 'demo') {
      const node = (await query('vault_nodes', { eq: ['id', 'Node-02'] }))[0];
      if (!node) return res.status(400).json({ error: 'Demo node not found.' });
      await change('vault_nodes', node.id, { status: 'OFFLINE', health_score: 0, partitioned: false, latency_ms: 0 });
      await log('FAILURE', 'Demo: Node-02 taken offline', 'Simulated node outage');
      const repaired = await repairAll();
      await log('REPAIR', 'Demo: automatic repair cycle completed', `${repaired} replicas restored on available nodes`);
      return res.status(200).json({ message: `Demo complete: Node-02 failed, ${repaired} replicas recovered. Restore Node-02 from the Nodes view.` });
    }
    return res.status(400).json({ error: 'Unknown action.' });
  } catch (e) { return apiError(res, e); }
}
