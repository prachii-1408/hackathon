import { cors, query, change, log, repairAll, updateAllStatuses, apiError } from './_core.js';
export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    if (req.method === 'GET') return res.status(200).json(await query('vault_nodes', { order: 'id', asc: true }));
    if (req.method === 'POST') {
      const { id, action } = req.body || {};
      const node = (await query('vault_nodes', { eq: ['id', id] }))[0];
      if (!node) return res.status(404).json({ error: 'Node not found.' });
      if (!['fail', 'recover', 'slow', 'partition', 'restore'].includes(action)) return res.status(400).json({ error: 'Invalid node action.' });
      let changes = {};
      if (action === 'fail') changes = { status: 'OFFLINE', health_score: 0, latency_ms: 0, partitioned: false };
      if (action === 'recover' || action === 'restore') changes = { status: 'RECOVERING', health_score: 75, latency_ms: 0, partitioned: false, last_heartbeat: new Date().toISOString() };
      if (action === 'slow') changes = { status: 'DEGRADED', health_score: 62, latency_ms: 900, partitioned: false };
      if (action === 'partition') changes = { status: 'DEGRADED', health_score: 35, partitioned: true, latency_ms: 0 };
      await change('vault_nodes', id, changes);
      await log(action === 'recover' || action === 'restore' ? 'RECOVERY' : 'FAILURE', `${id} ${action === 'fail' ? 'went offline' : action === 'slow' ? 'is experiencing latency' : action === 'partition' ? 'network partitioned' : 'returned to service'}`, 'Node control action');
      if (action === 'fail' || action === 'partition') await updateAllStatuses();
      const repaired = await repairAll();
      if (action === 'recover' || action === 'restore') await change('vault_nodes', id, { status: 'ONLINE', health_score: 100, last_heartbeat: new Date().toISOString() });
      return res.status(200).json({ ok: true, repaired });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) { return apiError(res, e); }
}
