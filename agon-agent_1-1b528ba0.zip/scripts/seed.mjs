import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw new Error('Missing Supabase environment variables');
const db = createClient(url, key);
const bucket = 'vault-replicas';
const samples = [
  { filename: 'architecture-overview.md', mime: 'text/markdown', content: '# Vault architecture\n\nFive logical storage nodes replicate files across independent node paths. The coordinator verifies every replica with SHA-256 before considering it healthy.\n\nRecovery: detect failure → select verified source → replicate → verify destination → update metadata and audit trail.\n', factor: 3, nodes: ['Node-01','Node-02','Node-03'] },
  { filename: 'cluster-config.json', mime: 'application/json', content: JSON.stringify({ cluster: 'vault-primary', region: 'demo-local', nodes: 5, replication: { default: 3, checksum: 'sha256' }, features: ['verification', 'repair', 'rebalance', 'failure-simulation'] }, null, 2), factor: 3, nodes: ['Node-02','Node-03','Node-04'] },
  { filename: 'recovery-runbook.txt', mime: 'text/plain', content: 'VAULT / RECOVERY RUNBOOK\n\n1. Identify unavailable nodes from the dashboard.\n2. Check object durability and audit events.\n3. Run integrity verification.\n4. Repair missing or corrupted replicas.\n5. Restore node connectivity and rebalance.\n\nNever delete the only healthy copy.\n', factor: 2, nodes: ['Node-01','Node-05'] },
  { filename: 'integrity-report.json', mime: 'application/json', content: JSON.stringify({ report: 'initial cluster verification', algorithm: 'SHA-256', result: 'passing', note: 'Demo object with independent verified copies' }, null, 2), factor: 2, nodes: ['Node-04','Node-05'] }
];
const must = (result) => { if (result.error) throw result.error; return result.data; };
try {
  await db.storage.updateBucket(bucket, { public: false, fileSizeLimit: 2097152, allowedMimeTypes: null });
} catch (e) { console.warn('Could not expand MIME types:', e.message); }
for (const sample of samples) {
  const existing = must(await db.from('vault_objects').select('id').eq('filename', sample.filename).limit(1));
  if (existing.length) { console.log('Already seeded:', sample.filename); continue; }
  const buffer = Buffer.from(sample.content, 'utf8');
  const id = crypto.randomUUID();
  const checksum = crypto.createHash('sha256').update(buffer).digest('hex');
  const object = must(await db.from('vault_objects').insert({ id, filename: sample.filename, mime_type: sample.mime, size_bytes: buffer.length, checksum, version: 1, replication_factor: sample.factor, status: 'PENDING' }).select().single());
  let written = 0;
  for (const nodeId of sample.nodes) {
    const path = `${nodeId}/${id}/v1`;
    must(await db.storage.from(bucket).upload(path, buffer, { contentType: sample.mime, upsert: true }));
    const blob = must(await db.storage.from(bucket).download(path));
    if (crypto.createHash('sha256').update(Buffer.from(await blob.arrayBuffer())).digest('hex') !== checksum) throw new Error(`Verification failed: ${path}`);
    must(await db.from('vault_replicas').insert({ id: crypto.randomUUID(), object_id: id, node_id: nodeId, path, checksum, status: 'HEALTHY', verified_at: new Date().toISOString() }).select().single());
    written++;
  }
  must(await db.from('vault_objects').update({ status: written === sample.factor ? 'HEALTHY' : 'DEGRADED' }).eq('id', object.id).select().single());
  must(await db.from('vault_audit').insert({ event_type: 'UPLOAD', message: `${sample.filename} stored with ${written}/${sample.factor} replicas`, detail: 'Seed object · SHA-256 verified' }).select().single());
  console.log('Seeded:', sample.filename, written, 'replicas');
}
const replicas = must(await db.from('vault_replicas').select('node_id, object_id'));
const objects = must(await db.from('vault_objects').select('id, size_bytes'));
for (const node of ['Node-01','Node-02','Node-03','Node-04','Node-05']) {
  const used = replicas.filter(r => r.node_id === node).reduce((sum, r) => sum + Number(objects.find(o => o.id === r.object_id)?.size_bytes || 0), 0);
  must(await db.from('vault_nodes').update({ used_bytes: used, write_ops: replicas.filter(r => r.node_id === node).length }).eq('id', node).select().single());
}
console.log('Vault seed complete');
