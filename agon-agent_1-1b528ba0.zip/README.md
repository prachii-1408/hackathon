# Vault — distributed object storage prototype

Vault is a working fault-tolerance simulator with a React/TypeScript dashboard and Vercel Node.js REST functions. It models five independent logical storage nodes (`Node-01`–`Node-05`). Supabase Postgres persists coordinator metadata, and separate node-prefixed objects in Supabase Storage hold actual replica bytes. This replaces local node directories/SQLite/Express for compatibility with stateless Vercel deployments; **the five nodes are logical fault domains, not separate physical servers**. Do not use this prototype to store sensitive or production-critical data.

## Run locally

1. `npm install`
2. Configure `.env` with `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`; use a Supabase project with the Vault tables and `vault-replicas` bucket provisioned.
3. `npx vercel dev` serves both Vite and `/api/*` functions (Vite alone does not serve the API).
4. `npm run build` validates the frontend.

## Architecture

- `api/objects.js` stores object metadata, distributes bytes to accessible nodes, re-downloads every written copy, and marks an object healthy only if enough copies exist. Upload limit: 2 MB to stay under serverless request size limits.
- `api/download.js` checks SHA-256 before delivery, tries the next replica on failure, and initiates repair. No unverified bytes are served.
- `api/nodes.js` simulates offline, degraded/slow, partitioned, and recovered nodes; node actions trigger durability reconciliation.
- `api/system.js` provides checksum sweeps, manual/automatic repair, injected corruption, rebalancing (copy → verify → remove), and the guided outage demo.
- `api/_core.js` is the coordinator/metadata service, replication engine, integrity worker, and repair worker shared by routes. Repair is run synchronously after relevant operations, not as a continuously running background process.
- `api/stream.js` streams short-lived SSE snapshots; the dashboard reconnects automatically and also polls as fallback.
- Supabase tables: `vault_nodes`, `vault_objects`, `vault_replicas`, `vault_audit`. The `vault-replicas` bucket stores bytes at `Node-XX/<object-id>/v<version>`.

## Try the demo

Upload a file with replication factor 3, then open **Activity → Run demo scenario**. Node-02 goes offline and automatic repair tries to restore durability on accessible nodes. In **Nodes**, recover Node-02. From an object's menu, inject corruption into a replica, run an integrity check, and inspect repair events. Download always verifies each copy and falls back when needed. Rebalance migrates copies only after verifying the destination.

## REST API

- `GET /api/state` — dashboard snapshot
- `GET /api/stream` — server-sent snapshot events
- `GET /api/objects`, `POST /api/objects`, `DELETE /api/objects` — list/upload/delete
- `GET /api/download?id=<uuid>` — verified binary download
- `GET /api/nodes`, `POST /api/nodes` — node list/control (`fail`, `recover`, `slow`, `partition`, `restore`)
- `POST /api/system` — `verify`, `repair`, `rebalance`, `corrupt`, `demo`

## Reliability and limitations

All healthy-copy decisions on active operations are based on SHA-256 verification. Repair never removes the sole verified copy; rebalancing writes and verifies before deleting its source. Explicit deletion removes all copies by user request. Audits persist failure, corruption, recovery, repair and movement. Offline copies remain physically present and become available again on node recovery. This is a shared demo environment without authentication; API access should be restricted before exposing to untrusted users. Object bytes share one underlying Supabase Storage service, so physical failure isolation is simulated rather than real. Serverless limits mean sweeps and repairs of very large object sets should be moved to a queued worker in a production architecture.
